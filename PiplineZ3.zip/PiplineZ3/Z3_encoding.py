from itertools import product
from collections import Counter
from Bio import SeqIO
from collections import defaultdict
import numpy as np

def creat_base_pair(pair_numbers):
    target_base_list = ['A', 'C', 'G', 'T']
    while pair_numbers != 1:
        target_base_list = [f'{i}{j}' for i, j in product(target_base_list, ['A', 'C', 'G', 'T'])]
        pair_numbers -= 1
    return target_base_list

def count_frequency(sequence, base_pair):
    sequence = sequence.split()
    counter = Counter(sequence)
    frequency_list = []
    base_pair_list = [base_pair[i:i+4] for i in range(0, len(base_pair), 4)]
    for base_list in base_pair_list:
        total_frequency = sum([counter[i] for i in base_list])
        for base in base_list:
            if total_frequency != 0:
                frequency_list.append(counter[base] / total_frequency)
            else:
                frequency_list.append(0)
    return frequency_list   

def creat_sequence_with_phase(sequence, k_length):
    seq_len = len(sequence)
    phase_sequence_list = []
    for phase in range(3):
        phase_sequence_list.append(' '.join([sequence[i:i+k_length] for i in range(phase, seq_len-k_length+1, 3)]))
    return phase_sequence_list

def calculate_z_parameters(frequency_list_in):
    grouped_list = [frequency_list_in[i:i+4] for i in range(0, len(frequency_list_in), 4)]
    encoded_list = []
    for [a, c, g, t] in grouped_list:
        x = (a + g) - (c + t)
        y = (a + c) - (g + t)
        z = (a + t) - (g + c)
        encoded_list += [x, y, z]
    return encoded_list

class ZCurveEncoderUnit:
    def __init__(self, sequence) -> None:
        self.sequence = sequence
    
    def encode(self, base_pair):
        k_length = len(base_pair[0])
        sequence = ' '.join([self.sequence[i:i+k_length] for i in range(len(self.sequence)-k_length+1)])
        return calculate_z_parameters(frequency_list_in=(count_frequency(sequence, base_pair)))
    
    def encode_phase(self, base_pair):
        phase_sequence_list = creat_sequence_with_phase(self.sequence, len(base_pair[0]))
        encoded_list = []
        for phase_sequence in phase_sequence_list:
            encoded_list += calculate_z_parameters(frequency_list_in=count_frequency(phase_sequence, base_pair))
        return encoded_list

def norm_unit(data):
    data = np.array(data)
    return (data - np.min(data)) / (np.max(data) - np.min(data)).tolist()

def main_encoder(fasta_path):
    base_pair_list = [creat_base_pair(i) for i in range(1, 4)]
    z_list = defaultdict(list)
    sequence_list = list(SeqIO.parse(fasta_path, 'fasta'))
    for sequence in sequence_list:
        encoder = ZCurveEncoderUnit(str(sequence.seq))
        encoded_list = []
        for base_pair in base_pair_list:
            encoded_list += encoder.encode(base_pair)
            encoded_list += encoder.encode_phase(base_pair)
        z_list[str(sequence.id)] = norm_unit(encoded_list)
    return z_list