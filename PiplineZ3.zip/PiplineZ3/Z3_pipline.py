import torch
from torch import nn
import torch.nn.functional as F
from Z3_encoding import main_encoder
from model_unit import MainModel
import argparse

def print_process_info(input_info):
    interval_info = ''.join(['>' for _ in range(100)])
    print(interval_info)
    print(input_info)

class Z3Pipline:
    def __init__(self, device, model_path, fasta_path, predict_result_file) -> None:
        self.device = device
        self.fasta_path = fasta_path
        self.predict_result_file = predict_result_file
        self.predict_model = torch.load(model_path, map_location=device)

    def predict(self):
        encoded_dict = main_encoder(self.fasta_path)
        timing_dict = {0:'Early', 1:'Late'}
        print_process_info(f'Start predict, result will save in:{self.predict_result_file}')
        with open(f'{self.predict_result_file}', 'w', encoding='utf-8') as result_file:
            for seq_id in encoded_dict:
                encode_tensor = torch.Tensor([encoded_dict[seq_id]]).to(self.device)
                pre_result = self.predict_model(encode_tensor)
                pre_result = pre_result[0]
                pre_label = torch.argmax(pre_result).item()
                pre_prop = pre_result[pre_label].item()
                result_file.write(f"SeqID:{seq_id} Timing:{timing_dict[pre_label]} Prop:{pre_prop}\n")
        print_process_info(f'Predict finished, result will save in:{self.predict_result_file}')

def clean_path(input_path, add=False):
    input_path = input_path.replace("\\\\", "/").replace("\\", "/")
    if add:
        if input_path[-1] != '/':
            input_path = f'{input_path}/'
    return input_path

def parametes():
    parametes_list = argparse.ArgumentParser(description='Using z3 to predict RT domains.')
    parametes_list.add_argument('-fasta_path', help='DNA sequence with fasta format', required=True)
    parametes_list.add_argument('-predict_result_file', help='Save the file of prediction results.', default='predict.out')
    parametes_list.add_argument('-model_path', help='Model path', default='Z3_model.pkl')
    parametes_list.add_argument('-device', help='CPU or GPU', default='cpu')
    return parametes_list.parse_args()

def main(device, model_path, fasta_path, predict_result_file):
    predict_pipline = Z3Pipline(device, model_path, fasta_path, predict_result_file)
    predict_pipline.predict()

if __name__ == '__main__':
    para = parametes()
    main(clean_path(para.device), 
         clean_path(para.model_path), 
         clean_path(para.fasta_path), 
         clean_path(para.predict_result_file))