import torch
from torch import nn
import torch.nn.functional as F

class Conv1dWithAttention(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, embed_dim, num_heads):
        super(Conv1dWithAttention, self).__init__()
        self.conv1d = nn.Conv1d(in_channels, out_channels, kernel_size, padding=kernel_size//2)
        self.mha = nn.MultiheadAttention(embed_dim=embed_dim, num_heads=num_heads)

    def forward(self, x):
        # x shape: (batch_size, in_channels, seq_len)
        x = self.conv1d(x)  # (batch_size, out_channels, seq_len)
        x = x.permute(2, 0, 1)  # (seq_len, batch_size, out_channels)
        attn_output, _ = self.mha(x, x, x)
        attn_output = attn_output.permute(1, 2, 0)  # (batch_size, out_channels, seq_len)
        return attn_output
    
class ChannelAttention(nn.Module):
    def __init__(self, in_channels, reduction_ratio=2):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.max_pool = nn.AdaptiveMaxPool1d(1)
        self.fc = nn.Sequential(
            nn.BatchNorm1d(in_channels),
            nn.Conv1d(in_channels, in_channels // reduction_ratio, 1, bias=False),
            nn.ELU(),
            nn.Conv1d(in_channels // reduction_ratio, in_channels, 1, bias=False),
            nn.ELU()
        )

    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return torch.tanh(out)

class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        self.conv1 = nn.Conv1d(2, 1, kernel_size=kernel_size, padding=kernel_size//2)

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        combined_out = torch.cat([avg_out, max_out], dim=1)
        attention_weight = torch.tanh(self.conv1(combined_out))
        return attention_weight

class CBAM(nn.Module):
    def __init__(self, in_channels) -> None:
        super().__init__()
        self.spatial = SpatialAttention()
        self.channel = ChannelAttention(in_channels)
    
    def forward(self, x):
        return x * self.spatial(x) * self.channel(x)

class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, kernel_size=3, padding=1):
        super(ResidualBlock, self).__init__()
        self.spatial_attention = SpatialAttention()
        self.channel_attention = ChannelAttention(out_channels)
        self.conv1 = nn.Sequential(
            nn.BatchNorm1d(in_channels),
            nn.Conv1d(in_channels, out_channels, kernel_size=kernel_size, stride=stride, padding=padding, bias=False),
            nn.ELU(),
        )
        self.conv2 = nn.Sequential(
            nn.BatchNorm1d(out_channels),
            nn.Conv1d(out_channels, out_channels, kernel_size=kernel_size, stride=1, padding=padding, bias=False),
            nn.ELU(),
        )
        
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.BatchNorm1d(in_channels),
                nn.Conv1d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.ELU(),
            )

    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)
        out += self.shortcut(x)
        return out

class ResNet(nn.Module):
    def __init__(self, input_channels, layer_numbers, interval_len, num_classes=2):
        super(ResNet, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv1d(input_channels, input_channels, kernel_size=7, stride=2, padding=3, bias=False),
            nn.ELU(),
            nn.Conv1d(input_channels, input_channels*2, kernel_size=1, bias=False),
            nn.ELU(),
        )
        self.layer_net, self.out_feature = self.build_res_layers(input_channels*2, layer_numbers, interval_len)
        self.avgpool_1 = nn.AdaptiveAvgPool1d(1)
        self.avgpool_2 = nn.AdaptiveMaxPool1d(1)
        self.fc = nn.Sequential(
            nn.Linear(self.out_feature, self.out_feature),
            nn.ELU(),
            nn.Linear(self.out_feature, self.out_feature),
            nn.ELU(),
            nn.Dropout(),
            nn.Linear(self.out_feature, num_classes),
            nn.Softmax(dim=-1),
        )

    def make_layer(self, in_channels, out_channels, blocks, stride):
        layers = []
        layers.append(ResidualBlock(in_channels, out_channels, stride))
        for _ in range(1, blocks):
            layers.append(ResidualBlock(out_channels, out_channels, stride=1))
        return nn.Sequential(*layers)

    def build_res_layers(self, input_channels, layer_numbers, interval_len):
        res_net = nn.Sequential()
        for layers in range(layer_numbers):
            res_net.add_module(
                name=f'L{layers + 1}',
                module=nn.Sequential(
                    nn.BatchNorm1d(input_channels),
                    self.make_layer(input_channels, input_channels+interval_len, blocks=4, stride=1),
                )
            )
            input_channels += interval_len
        return res_net, input_channels

    def forward(self, x):
        out = self.conv1(x)
        out = self.layer_net(out)
        out = self.avgpool_1(out) * self.avgpool_2(out)
        out = torch.flatten(out, 1)
        out = self.fc(out)
        return out

class FeatureNet(nn.Module):
    def __init__(self, input_feature, output_feature, layer_numbers) -> None:
        super().__init__()
        self.layer = self.build_feature_net(input_feature, output_feature, layer_numbers)

    def init_feature_net(self, input_feature, output_feature):
        net_list = []
        net_list.append(nn.Linear(input_feature, output_feature))
        net_list.append(nn.ELU())
        net_list.append(nn.Dropout())
        return net_list

    def build_feature_net(self, input_feature, output_feature, layer_numbers):
        net_list = self.init_feature_net(input_feature, output_feature)
        for _ in range(layer_numbers):
            net_list.append(nn.LayerNorm(output_feature))
            net_list.append(nn.Linear(output_feature, output_feature))
            net_list.append(nn.ELU())
        return nn.Sequential(*net_list)

    def forward(self, x):
        x = self.layer(x)
        return x
    
class MainModel(nn.Module):
    def __init__(self, input_feature, output_feature=100, input_channels=5, layer_numbers=2, interval_len=3) -> None:
        super().__init__()
        self.input_feature = input_feature
        self.input_channels = input_channels
        self.output_feature = output_feature
        self.feature_1 = FeatureNet(input_feature, output_feature, layer_numbers)
        # self.feature_2 = FeatureNet(input_feature, output_feature, layer_numbers)
        self.cbam_1 = CBAM(input_channels)
        self.res_net = ResNet(input_channels, layer_numbers, interval_len)
 
    def forward(self, x):
        # print(x.shape)    
        x = torch.reshape(x, (x.shape[0], 1, x.shape[-1]))
        x = self.feature_1(x)
        x = torch.reshape(x, (x.shape[0], self.input_channels, self.output_feature // self.input_channels))
        x = self.res_net(self.cbam_1(x))
        return x 

